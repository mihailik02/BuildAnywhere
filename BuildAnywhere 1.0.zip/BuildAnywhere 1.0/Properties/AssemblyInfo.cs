using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyTitle("BuildAnywhere")]
[assembly: AssemblyDescription("Mod created by Fumihiko")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Fumihiko")]
[assembly: AssemblyProduct("BuildAnywhere")]
[assembly: AssemblyCopyright("Copyright Fumihiko 2020")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("067df614-d989-40ed-bdbe-c47828f399fc")]
[assembly: AssemblyFileVersion("1.0")]
[assembly: AssemblyVersion("1.0")]
